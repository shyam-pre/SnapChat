export default {
    INITIAL_SCREEN:"initialScreen",
    SIGNUP:"signup",
    LOGIN:"login",
    MAP: "map",
    CHAT:"chat",
    CAMERA:"camera",
    STORIES:"stories",
}