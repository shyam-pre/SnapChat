export const data = [
{
    id: 0,
    name: 'Mahip',
    img: 'https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg',
    streak: 103,
    time: '22m',
},
{
    id: 1,
    name: 'Neha Tipsy',
    img: 'https://expertphotography.com/wp-content/uploads/2018/10/cool-profile-pictures-retouching-1.jpg',
    streak: 103,
    time: '23m',
},
{
    id: 2,
    name: 'Sonali Sharma',
    img: 'https://akm-img-a-in.tosshub.com/indiatoday/images/story/202102/google_pay__7__1200x768.jpeg?WJeXdcrm_vaY0K7AWpMp5bXZ65NH_4dg&size=770:433',
    streak: 285,
    time: '1h',
},
{
    id: 3,
    name: 'Javed Khan',
    img: 'https://image.shutterstock.com/image-photo/head-shot-young-attractive-businessman-260nw-1854697390.jpg',
    streak: 13,
    time: '2h',
},
{
    id: 4,
    name: 'Anupriya',
    img: 'https://blog.photofeeler.com/wp-content/uploads/2017/09/tinder-photo-size-tinder-picture-size-tinder-aspect-ratio-image-dimensions-crop.jpg',
    streak: 201,
    time: '1h',
},

]