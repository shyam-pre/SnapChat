export default {
    IS_LOGIN: "IS_LOGIN",
    CLEARE_REDUX_STATE: "CLEAR_REDUX_STATE",
}