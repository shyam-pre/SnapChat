import * as auth from './auth';
import * as users from './users';
export default {
    ...auth,
    ...users,
}