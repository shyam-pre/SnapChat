export default {
    regular: 'Barlow-Regular',
    medium: 'Barlow-Medium',
    bold: 'Barlow-Bold'
}