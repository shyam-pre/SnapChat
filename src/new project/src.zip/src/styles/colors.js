export default {
    red: '#f23b57',
    blue: '#10adff',
    white: '#ffffff',
    green: 'green',
    black: '#111111',
    blackOpacity10: 'rgba(0,0,0,0.1)',
    blackOpacity20: 'rgba(0,0,0,0.2)',
    blackOpacity30: 'rgba(0,0,0,0.3)',
    blackOpacity40: 'rgba(0,0,0,0.4)',
    blackOpacity50: 'rgba(0,0,0,0.5)'
}